<?php

use Symfony\Component\Routing\Exception\MethodNotAllowedException;
use Symfony\Component\Routing\Exception\ResourceNotFoundException;
use Symfony\Component\Routing\RequestContext;

/**
 * This class has been auto-generated
 * by the Symfony Routing Component.
 */
class appProdProjectContainerUrlMatcher extends Symfony\Bundle\FrameworkBundle\Routing\RedirectableUrlMatcher
{
    public function __construct(RequestContext $context)
    {
        $this->context = $context;
    }

    public function match($rawPathinfo)
    {
        $allow = [];
        $pathinfo = rawurldecode($rawPathinfo);
        $trimmedPathinfo = rtrim($pathinfo, '/');
        $context = $this->context;
        $request = $this->request ?: $this->createRequest($pathinfo);
        $requestMethod = $canonicalMethod = $context->getMethod();

        if ('HEAD' === $requestMethod) {
            $canonicalMethod = 'GET';
        }

        if (0 === strpos($pathinfo, '/eventManagement')) {
            // event_management
            if ('/eventManagement' === $pathinfo) {
                return array (  '_controller' => 'AppBundle\\Controller\\eventManagementController::listAction',  '_route' => 'event_management',);
            }

            // event_create
            if ('/eventManagement/create' === $pathinfo) {
                return array (  '_controller' => 'AppBundle\\Controller\\eventManagementController::createAction',  '_route' => 'event_create',);
            }

            // event_edit
            if (0 === strpos($pathinfo, '/eventManagement/edit') && preg_match('#^/eventManagement/edit/(?P<id>[^/]++)$#sD', $pathinfo, $matches)) {
                return $this->mergeDefaults(array_replace($matches, ['_route' => 'event_edit']), array (  '_controller' => 'AppBundle\\Controller\\eventManagementController::editAction',));
            }

            // event_views
            if (0 === strpos($pathinfo, '/eventManagement/views') && preg_match('#^/eventManagement/views/(?P<id>[^/]++)$#sD', $pathinfo, $matches)) {
                return $this->mergeDefaults(array_replace($matches, ['_route' => 'event_views']), array (  '_controller' => 'AppBundle\\Controller\\eventManagementController::detailsAction',));
            }

            // event_delete
            if (0 === strpos($pathinfo, '/eventManagement/delete') && preg_match('#^/eventManagement/delete/(?P<id>[^/]++)$#sD', $pathinfo, $matches)) {
                return $this->mergeDefaults(array_replace($matches, ['_route' => 'event_delete']), array (  '_controller' => 'AppBundle\\Controller\\eventManagementController::deleteAction',));
            }

        }

        if ('/' === $pathinfo && !$allow) {
            throw new Symfony\Component\Routing\Exception\NoConfigurationException();
        }

        throw 0 < count($allow) ? new MethodNotAllowedException(array_unique($allow)) : new ResourceNotFoundException();
    }
}
