<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* eventManagement/views.html.twig */
class __TwigTemplate_8f089ebc00a086df83dbc8bfbfc314ae2b1568d53ee6c6fcefe8723e95062b06 extends \Twig\Template
{
    public function __construct(Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("base.html.twig", "eventManagement/views.html.twig", 1);
        $this->blocks = [
            'body' => [$this, 'block_body'],
        ];
    }

    protected function doGetParent(array $context)
    {
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 2
    public function block_body($context, array $blocks = [])
    {
        // line 3
        echo "
       <a class=\"btn btn-default\" href=\"/eventManagement\">Back to home</a>
       <hr>
       <h2 class=\"page-header\">";
        // line 6
        echo twig_escape_filter($this->env, $this->getAttribute(($context["todo"] ?? null), "name", []), "html", null, true);
        echo "</h2>
       <ul class=\"list-group\">
               <li class=\"list-group-item\">Event Date: <strong> ";
        // line 8
        echo twig_escape_filter($this->env, twig_date_format_filter($this->env, $this->getAttribute(($context["todo"] ?? null), "eventdate", []), "F j, Y, g:i a"), "html", null, true);
        echo "</strong></li>
               <li class=\"list-group-item\">Description: ";
        // line 9
        echo twig_escape_filter($this->env, $this->getAttribute(($context["todo"] ?? null), "description", []), "html", null, true);
        echo "</li>
               <li class=\"list-group-item\">image: <strong> ";
        // line 10
        echo twig_escape_filter($this->env, $this->getAttribute(($context["todo"] ?? null), "image", []), "html", null, true);
        echo " </strong> </li>
               <li class=\"list-group-item\">Capacity: <strong> ";
        // line 11
        echo twig_escape_filter($this->env, $this->getAttribute(($context["todo"] ?? null), "capacity", []), "html", null, true);
        echo " </strong> </li>
               <li class=\"list-group-item\">Email: <strong> ";
        // line 12
        echo twig_escape_filter($this->env, $this->getAttribute(($context["todo"] ?? null), "email", []), "html", null, true);
        echo " </strong> </li>
               <li class=\"list-group-item\">phone Number: <strong> ";
        // line 13
        echo twig_escape_filter($this->env, $this->getAttribute(($context["todo"] ?? null), "phonenumber", []), "html", null, true);
        echo " </strong> </li>
                <li class=\"list-group-item\">Address: <strong> ";
        // line 14
        echo twig_escape_filter($this->env, $this->getAttribute(($context["todo"] ?? null), "address", []), "html", null, true);
        echo " </strong> </li>
               <li class=\"list-group-item\">URL: <strong> ";
        // line 15
        echo twig_escape_filter($this->env, $this->getAttribute(($context["todo"] ?? null), "uRL", []), "html", null, true);
        echo " </strong> </li>
               <li class=\"list-group-item\">Type: <strong> ";
        // line 16
        echo twig_escape_filter($this->env, $this->getAttribute(($context["todo"] ?? null), "type", []), "html", null, true);
        echo " </strong> </li>

       </ul>
       \t<img src=\"img/don.jpg\" alt=\"technology\">
           

";
    }

    public function getTemplateName()
    {
        return "eventManagement/views.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  84 => 16,  80 => 15,  76 => 14,  72 => 13,  68 => 12,  64 => 11,  60 => 10,  56 => 9,  52 => 8,  47 => 6,  42 => 3,  39 => 2,  22 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Source("", "eventManagement/views.html.twig", "/Applications/XAMPP/xamppfiles/htdocs/eventManagement/app/Resources/views/eventManagement/views.html.twig");
    }
}
