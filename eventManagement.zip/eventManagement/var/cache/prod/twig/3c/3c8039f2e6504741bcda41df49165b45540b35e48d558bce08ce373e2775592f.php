<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* base.html.twig */
class __TwigTemplate_48d3d711a5b05a1a83fce01ac56273d97ea1b5e0b01570eb9a0d96069e249a7e extends \Twig\Template
{
    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = [
            'title' => [$this, 'block_title'],
            'stylesheets' => [$this, 'block_stylesheets'],
            'body' => [$this, 'block_body'],
            'javascripts' => [$this, 'block_javascripts'],
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        // line 1
        echo "<!DOCTYPE html>
<html lang=\"en\">
 <head>
   <meta charset=\"utf-8\">
   <meta http-equiv=\"X-UA-Compatible\" content=\"IE=edge\">
   <meta name=\"viewport\" content=\"width=device-width, initial-scale=1\">

   <title>";
        // line 8
        $this->displayBlock('title', $context, $blocks);
        echo "</title>
   <!-- Bootstrap core CSS -->
  <link href=\"https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css\" rel=\"stylesheet\">
   ";
        // line 11
        $this->displayBlock('stylesheets', $context, $blocks);
        // line 12
        echo "       <link rel=\"icon\" type=\"image/x-icon\" href=\"";
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("favicon.ico"), "html", null, true);
        echo "\" />
 </head>
 <body>
   <nav class=\"navbar navbar-inverse\" style=\"background-color: #273c75; color:white;\">
    
       <div class=\"navbar-header\">
         <button type=\"button\" class=\"navbar-toggle collapsed\" data-toggle=\"collapse\" data-target=\"#navbar\" aria-expanded=\"false\" aria-controls=\"navbar\">
           <span class=\"sr-only\">Toggle navigation</span>
           <span class=\"icon-bar\"></span>
           <span class=\"icon-bar\"></span>
           <span class=\"icon-bar\"></span>
         </button>
         <a class=\"navbar-brand\" href=\"/eventManagement\">Search for event</a>
       </div>
       <div id=\"navbar\" class=\"collapse navbar-collapse\">
         <ul class=\"nav navbar-nav\">
           <li><a href=\"/eventManagement\">Home</a></li>
           <li><a href=\"/eventManagement/create\">Add Event</a></li>
         </ul>
       </div><!--/.nav-collapse -->
     </div>
   </nav>
   <div class=\"container-fluid\">
<div class=\"row\">
<div class=\"col-md-8\">
   ";
        // line 37
        $this->displayBlock('body', $context, $blocks);
        // line 38
        echo "</div>
</div>
    
   </div><!-- /.container -->
";
        // line 42
        $this->displayBlock('javascripts', $context, $blocks);
        // line 43
        echo " </body>
</html>";
    }

    // line 8
    public function block_title($context, array $blocks = [])
    {
        echo "Search for event!";
    }

    // line 11
    public function block_stylesheets($context, array $blocks = [])
    {
    }

    // line 37
    public function block_body($context, array $blocks = [])
    {
    }

    // line 42
    public function block_javascripts($context, array $blocks = [])
    {
    }

    public function getTemplateName()
    {
        return "base.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  111 => 42,  106 => 37,  101 => 11,  95 => 8,  90 => 43,  88 => 42,  82 => 38,  80 => 37,  51 => 12,  49 => 11,  43 => 8,  34 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Source("", "base.html.twig", "/Applications/XAMPP/xamppfiles/htdocs/eventManagement/app/Resources/views/base.html.twig");
    }
}
