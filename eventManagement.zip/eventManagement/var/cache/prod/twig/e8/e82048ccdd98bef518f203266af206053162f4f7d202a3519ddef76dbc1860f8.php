<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* eventManagement/index.html.twig */
class __TwigTemplate_66bb4b268921d9a1e5a4921a7a0700c906ad8d820f595db68c0deb20e95003df extends \Twig\Template
{
    public function __construct(Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("base.html.twig", "eventManagement/index.html.twig", 1);
        $this->blocks = [
            'body' => [$this, 'block_body'],
        ];
    }

    protected function doGetParent(array $context)
    {
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 2
    public function block_body($context, array $blocks = [])
    {
        // line 3
        echo "       
<h2 class=\"page-header\"> Available Events......! </h2>
<div class=\"container\">
  <table class=\"table table-striped\">
   <thead class=\"thead-dark\"> 
       <tr>
           <th>#</th>
           <th>Name</th>
           <th>Event Date</th>
           <th>Description</th>
           <th>Image</th>
           <th>Capacity</th>
           <th>E-mail</th>
           <th>Phone Number</th>
           <th>Address</th>
           <th>Website</th>
           <th>Type</th>
           <th>#Action</th>
       </tr>
   </thead>
";
        // line 23
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(($context["todos"] ?? null));
        foreach ($context['_seq'] as $context["_key"] => $context["todo"]) {
            // line 24
            echo "   <tbody>
       <tr>
           <th scope=\"row\">";
            // line 26
            echo twig_escape_filter($this->env, $this->getAttribute($context["todo"], "id", []), "html", null, true);
            echo "</th>
           <td>";
            // line 27
            echo twig_escape_filter($this->env, $this->getAttribute($context["todo"], "name", []), "html", null, true);
            echo "</td>
           <td>";
            // line 28
            echo twig_escape_filter($this->env, twig_date_format_filter($this->env, $this->getAttribute($context["todo"], "eventdate", []), "F j, Y, g:i a"), "html", null, true);
            echo "</td>
           <td>";
            // line 29
            echo twig_escape_filter($this->env, $this->getAttribute($context["todo"], "description", []), "html", null, true);
            echo "</td>
           <td>";
            // line 30
            echo twig_escape_filter($this->env, $this->getAttribute($context["todo"], "image", []), "html", null, true);
            echo "</td>
           <td>";
            // line 31
            echo twig_escape_filter($this->env, $this->getAttribute($context["todo"], "capacity", []), "html", null, true);
            echo "</td>
           <td>";
            // line 32
            echo twig_escape_filter($this->env, $this->getAttribute($context["todo"], "email", []), "html", null, true);
            echo "</td>
           <td>";
            // line 33
            echo twig_escape_filter($this->env, $this->getAttribute($context["todo"], "phonenumber", []), "html", null, true);
            echo "</td>
           <td>";
            // line 34
            echo twig_escape_filter($this->env, $this->getAttribute($context["todo"], "address", []), "html", null, true);
            echo "</td>
           <td>";
            // line 35
            echo twig_escape_filter($this->env, $this->getAttribute($context["todo"], "uRL", []), "html", null, true);
            echo "</td>
           <td>";
            // line 36
            echo twig_escape_filter($this->env, $this->getAttribute($context["todo"], "type", []), "html", null, true);
            echo "</td>
           <td> <a href=\"/eventManagement/views/";
            // line 37
            echo twig_escape_filter($this->env, $this->getAttribute($context["todo"], "id", []), "html", null, true);
            echo "\" class=\"btn btn-success\">View</a>
                   
           <a href=\"/eventManagement/edit/";
            // line 39
            echo twig_escape_filter($this->env, $this->getAttribute($context["todo"], "id", []), "html", null, true);
            echo "\" class=\"btn btn-default\">Edit</a>
           <a href=\"/eventManagement/delete/";
            // line 40
            echo twig_escape_filter($this->env, $this->getAttribute($context["todo"], "id", []), "html", null, true);
            echo "\" class=\"btn btn-danger\">Delete</a>        
           </td>
       </tr> 
";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['todo'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 44
        echo "   </tbody>
   </table>
</div>
";
    }

    public function getTemplateName()
    {
        return "eventManagement/index.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  135 => 44,  125 => 40,  121 => 39,  116 => 37,  112 => 36,  108 => 35,  104 => 34,  100 => 33,  96 => 32,  92 => 31,  88 => 30,  84 => 29,  80 => 28,  76 => 27,  72 => 26,  68 => 24,  64 => 23,  42 => 3,  39 => 2,  22 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Source("", "eventManagement/index.html.twig", "/Applications/XAMPP/xamppfiles/htdocs/eventManagement/app/Resources/views/eventManagement/index.html.twig");
    }
}
